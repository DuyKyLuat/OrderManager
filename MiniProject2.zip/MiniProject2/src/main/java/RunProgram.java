import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.Scanner;

import static java.lang.Float.parseFloat;
import static java.lang.Integer.parseInt;

public class RunProgram{
    static Scanner sc = new Scanner(System.in);
    static String jdbcURL;
    static String username;
    static String password;
    public static void importData() {
        System.out.println("Nhập đường dẫn file CSV cần Import: ");
        String filePath = sc.nextLine();

        int batchSize = 5;

        try (Connection connection = DriverManager.getConnection(jdbcURL, username, password)) {
            connection.setAutoCommit(false);

            String sql = "INSERT INTO HospitalCharges(DRG_Definition, Provider_Id, Provider_Name, Provider_Street_Address, " +
                    "Provider_City, Provider_State, Provider_Zip_Code, Hospital_Referral_Region_Description, " +
                    "Total_Discharges, Average_Covered_Charges, Average_Total_Payments, Average_Medicare_Payments)" +
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";

            try (PreparedStatement statement = connection.prepareStatement(sql);
                 BufferedReader lineReader = new BufferedReader(new FileReader(filePath))) {

                String lineText;
                int count = 0;
                lineReader.readLine();

                while ((lineText = lineReader.readLine()) != null) {
                    String[] data = lineText.split(";");
                    if (data.length >= 12) {
                        statement.setString(1, data[0]);
                        statement.setInt(2, parseInt(data[1]));
                        statement.setString(3, data[2]);
                        statement.setString(4, data[3]);
                        statement.setString(5, data[4]);
                        statement.setString(6, data[5]);
                        statement.setInt(7, parseInt(data[6]));
                        statement.setString(8, data[7]);
                        statement.setInt(9, parseInt(data[8]));

                        try {
                            statement.setFloat(10, parseFloat(data[9]));
                            statement.setFloat(11, parseFloat(data[10]));
                            statement.setFloat(12, parseFloat(data[11]));
                        } catch (NumberFormatException e) {
                            // Xử lý nếu giá trị không hợp lệ
                            System.out.println("Giá trị đầu vào không hợp lệ : " + lineText);
                            continue;
                        }

                        statement.addBatch();
                        if (++count % batchSize == 0) {
                            statement.executeBatch();
                        }
                    } else {
                        System.out.println("Bỏ qua dòng không hợp lệ: " + lineText);
                    }
                }

                statement.executeBatch();
                connection.commit();
                System.out.println("Dữ liệu đã được thêm vào thành công.");
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public static void exportData() {
        System.out.println("Nhập đường dẫn file CSV cần Export: ");
        String filePathEx = sc.nextLine();
        // kết nối tới MySQL
        try (Connection connection = DriverManager.getConnection(jdbcURL, username, password)) {
            if (connection != null) {
                String selectSQL = "SELECT * FROM HospitalCharges"; // lấy tất cả các dòng từ bảng
                try (PreparedStatement preparedStatement = connection.prepareStatement(selectSQL);
                     //Thực thi câu SQL và nhận một result set
                     ResultSet resultSet = preparedStatement.executeQuery()) {
                    //ghi dữ liệu vào tập tin CSV theo đường dẫn được nhập từ người dùng.
                    try (FileWriter csvWriter = new FileWriter(filePathEx)) {
                        //Ghi tiêu đề của các cột vào tập tin CSV cách nhau bằng ";"
                        writeCsvHeader(resultSet, csvWriter);
                        // Duyệt qua resultSet cách nhau ;
                        writeCsvData(resultSet, csvWriter);
                    }

                    System.out.println("Dữ liệu đã được xuất ra " + filePathEx);
                }
            }
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }

    //ghi tiêu đề
    private static void writeCsvHeader(ResultSet resultSet, FileWriter csvWriter) throws SQLException, IOException {
        //Lấy số lượng cột từ ResultSet Metadata
        int columnCount = resultSet.getMetaData().getColumnCount();
        //Thêm tên của cột vào csvWriter được sử dụng để ghi vào tệp CSV
        for (int i = 1; i <= columnCount; i++) {
            csvWriter.append(resultSet.getMetaData().getColumnName(i));
            // thêm dấu chấm phẩy
            if (i < columnCount) {
                csvWriter.append(";");
            }
        }
        // thêm ký tự xuống dòng vào tiêu đề
        csvWriter.append("\n");
    }
    // ghi nội dung
    private static void writeCsvData(ResultSet resultSet, FileWriter csvWriter) throws SQLException, IOException {
        // trả về số lượng cột
        int columnCount = resultSet.getMetaData().getColumnCount();
        //Di chuyển từ dòng này sang dòng khác ->  không còn dòng nào, vòng lặp sẽ dừng.
        while (resultSet.next()) {
            // lặp qua từng cột.
            for (int i = 1; i <= columnCount; i++) {
                csvWriter.append(resultSet.getString(i));//Thêm giá trị của cột thứ (i)vào
                if (i < columnCount) { // Thêm dấu chấm phẩy
                    csvWriter.append(";");
                }
            }
            // thêm xuống dòng
            csvWriter.append("\n");
        }
    }

    // tính giá trị nhỏ nhất
    public static void CalculateMinDRGCost(Connection connection) throws SQLException {
        System.out.println("Nhập tên cột để thêm giá trị vào: ");
        String newNameTable = sc.nextLine();
        String sql = "SELECT DRG_Definition, MIN(Average_Total_Payments) AS " + newNameTable + " FROM HospitalCharges GROUP BY DRG_Definition;";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                String drgDefinition = resultSet.getString("DRG_Definition");
                float minCost = resultSet.getFloat(newNameTable);
                System.out.println(drgDefinition + ": " + minCost);
            }
        }
    }
    // tính giá trị lớn nhất
    public static void CalculateMaxDRGCost(Connection connection) throws SQLException {
        System.out.println("Nhập tên cột để thêm giá trị vào: ");
        String newNameTable1 = sc.nextLine();
        String sql = "SELECT DRG_Definition, MAX(Average_Total_Payments) AS " + newNameTable1 + " FROM HospitalCharges GROUP BY DRG_Definition;";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                String drgDefinition = resultSet.getString("DRG_Definition");
                float maxCost = resultSet.getFloat(newNameTable1);
                System.out.println(drgDefinition + ": " + maxCost);
            }
        }
    }

    // tính trung bình cộng
    public static void CalculateAverageDRGCost(Connection connection) throws SQLException {
        System.out.println("Nhập tên cột để thêm giá trị vào: ");
        String newNameTable2 = sc.nextLine();
        String sql = "SELECT DRG_Definition, AVG(Average_Total_Payments) AS " + newNameTable2 + " FROM HospitalCharges GROUP BY DRG_Definition";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                String drgDefinition = resultSet.getString("DRG_Definition");
                float avgCost = resultSet.getFloat(newNameTable2);
                System.out.println(drgDefinition + ": " + avgCost + "$");
            }
        }
    }
    // form nhập liệu
    public static void EnterInputInformation() {
        System.out.println("Nhập JDBC URL:");
        jdbcURL = sc.nextLine();

        System.out.println("Nhập User Name:");
        username = sc.nextLine();

        System.out.println("Nhập Password:");
        password = sc.nextLine();
    }
}
