import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Scanner;

class MiniProject2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {

        System.out.println("Chuyển đổi dữ liệu");
        System.out.println("1. Nhập kết quả từ Excel vào MySQL");
        System.out.println("2. Xuất kết quả MySQL ra Excel.CSV");
        System.out.println("3. Tính giá trị trung bình, giá trị cao nhất, giá trị thấp nhất của từng DRG ");
        System.out.println("4. Thoát");

        System.out.print("Chọn chức năng cần thực hiện: ");
        int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    RunProgram.EnterInputInformation();
                    RunProgram.importData();
                    break;
                case 2:
                    RunProgram.EnterInputInformation();
                    RunProgram.exportData();
                    break;
                case 3:
                    System.out.println("3.1. Tính toán giá trị trung bình của DRG ");
                    System.out.println("3.2. Tìm giá trị lớn nhất của DRG");
                    System.out.println("3.3. Tìm giá trị nhỏ nhất của DRG");
                    int choice1 = sc.nextInt();
                    RunProgram.EnterInputInformation();
                    try {
                        Connection connection = DriverManager.getConnection(RunProgram.jdbcURL, RunProgram.username, RunProgram.password);
                        if ( choice1 == 1 ) {
                            RunProgram.CalculateAverageDRGCost(connection);
                        } else if ( choice1 == 2 ) {
                            RunProgram.CalculateMaxDRGCost(connection);
                        } else if ( choice1 == 3 ) {
                            RunProgram.CalculateMinDRGCost(connection);
                        } else {
                            System.out.println("Invalid choice");
                            return;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case 4:
                    System.out.println("Exiting program.");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice");
                    break;
            }
        }
    }
}